# colors variables. 
RED='\033[0;31m'
GREEN='\033[0;32m'
NOCOLOR='\033[0m'
